package com.example.echo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StoreActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var et_productName: EditText
    private lateinit var et_productCont: EditText
    private lateinit var et_productPrice: EditText
    private lateinit var et_productPrio: EditText
    private lateinit var btt_product: Button
    private lateinit var tv_listProduct: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_store)

        sharedPreferences = getSharedPreferences("ComprasPrefs", Context.MODE_PRIVATE)

        et_productName = findViewById(R.id.et_productName)
        et_productCont = findViewById(R.id.et_productCont)
        et_productPrice = findViewById(R.id.et_productPrice)
        et_productPrio = findViewById(R.id.et_productPrio)
        btt_product = findViewById(R.id.btt_product)
        tv_listProduct = findViewById(R.id.tv_listProduct)

        cargarListaCompras()

        btt_product.setOnClickListener {
            agregarProducto()
        }
    }

    private fun agregarProducto() {
        val producto = et_productName.text.toString()
        val cantidad = et_productCont.text.toString()
        val precio = et_productPrice.text.toString()
        val prioridad = et_productPrio.text.toString()

        if (producto.isNotEmpty() && cantidad.isNotEmpty() && precio.isNotEmpty() && prioridad.isNotEmpty()) {
            val compra = "$producto - Cantidad: $cantidad - Precio: $$precio - Prioridad: $prioridad\n"
            val comprasGuardadas = sharedPreferences.getString("lista_compras", "")

            sharedPreferences.edit().putString("lista_compras", comprasGuardadas + compra).apply()
            cargarListaCompras()

            et_productName.text.clear()
            et_productCont.text.clear()
            et_productPrice.text.clear()
            et_productPrio.text.clear()
        }
    }

    private fun cargarListaCompras() {
        val compras = sharedPreferences.getString("lista_compras", "No hay compras registradas")
        tv_listProduct.text = compras
    }

    override fun onStart() {
        super.onStart()
        Log.d("ProfileActivity", "onStart: Activity Profile esta en primer plano")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ProfileActivity", "onResume: Activity Profile esta ejecutandose")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ProfileActivity", "onPause: Activity Profile ha sido pausada")
    }
    override fun onStop() {
        super.onStop()
        Log.d("ProfileActivity", "onStop: Activity Profile ha sido detenida")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ProfileActivity", "onDestroy: Activity Profile ha sido destruida")
    }
}


