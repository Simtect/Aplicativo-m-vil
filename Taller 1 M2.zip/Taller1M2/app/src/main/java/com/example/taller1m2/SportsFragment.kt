package com.example.taller1m2

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import org.json.JSONArray
import org.json.JSONObject

class SportsFragment : Fragment() {

    private lateinit var listView: ListView
    private lateinit var prefs: SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Deportes"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_sports, container, false)

        listView = view.findViewById(R.id.lv_listaProductos)
        prefs = requireContext().getSharedPreferences("carrito", Context.MODE_PRIVATE)

        val productos = listOf(
            mapOf("nombre" to "balon de Futbol", "descripcion" to "Ideal para comenzar con las tres b; bueno, bonito y barato", "precio" to "Precio: $49.900", "cantidad" to "Disponible: 15"),
            mapOf("nombre" to "Balón de Basketball", "descripcion" to "Perfecto para entrenamientos y partidos amistosos", "precio" to "Precio: $79.900", "cantidad" to "Disponible: 9"),
            mapOf("nombre" to "Pelotas de tenis", "descripcion" to "Perfectas para practicar", "precio" to "Precio: $19.900", "cantidad" to "Disponible: 14")
        )

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = productos.size
            override fun getItem(position: Int): Any = productos[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val inflater = LayoutInflater.from(requireContext())
                val viewItem = convertView ?: inflater.inflate(R.layout.item_product, parent, false)

                val producto = productos[position]

                viewItem.findViewById<TextView>(R.id.tv_lineaNombre).text = producto["nombre"]
                viewItem.findViewById<TextView>(R.id.tv_lineaDescripcion).text = producto["descripcion"]
                viewItem.findViewById<TextView>(R.id.tv_lineaPrecio).text = producto["precio"]
                viewItem.findViewById<TextView>(R.id.tv_lineaCantidad).text = producto["cantidad"]

                viewItem.findViewById<Button>(R.id.btt_agregar).setOnClickListener {
                    agregarAlCarrito(producto)
                    Toast.makeText(requireContext(), "${producto["nombre"]} añadido al carrito", Toast.LENGTH_SHORT).show()
                }

                return viewItem
            }
        }

        listView.adapter = adapter
        return view
    }

    private fun agregarAlCarrito(producto: Map<String, String>) {
        val carritoActual = prefs.getString("productos", "[]")
        val jsonArray = JSONArray(carritoActual)

        val nombreNuevo = producto["nombre"]
        var productoExiste = false

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            if (item.getString("nombre") == nombreNuevo) {
                val cantidadActual = item.optInt("cantidadSeleccionada", 1)
                item.put("cantidadSeleccionada", cantidadActual + 1)
                productoExiste = true
                break
            }
        }

        if (!productoExiste) {
            val nuevoProducto = JSONObject()
            for ((key, value) in producto) {
                nuevoProducto.put(key, value)
            }
            nuevoProducto.put("cantidadSeleccionada", 1)
            jsonArray.put(nuevoProducto)
        }

        prefs.edit().putString("productos", jsonArray.toString()).apply()
    }
}