package com.example.taller1m2

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)

        // Ítems del menú
        val itemInicio = findViewById<TextView>(R.id.tv_itemInicio)
        val itemProductos = findViewById<TextView>(R.id.tv_itemProductos)
        val itemPerfil = findViewById<TextView>(R.id.tv_itemPerfil)
        val itemCategorias = findViewById<TextView>(R.id.tv_itemCategorias)
        val itemCarrito = findViewById<TextView>(R.id.tv_itemCarrito)
        val itemLogin = findViewById<TextView>(R.id.tv_itemLogin)


        val prefs = getSharedPreferences("sesion", MODE_PRIVATE)
        val usuario = prefs.getString("usuario", null)

        if (usuario == null) {
            itemPerfil.visibility = View.GONE
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, StartFragment())
            .commit()

        itemInicio.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, StartFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        itemLogin.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, LoginFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        itemProductos.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, ProductsFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        itemPerfil.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, ProfileFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        itemCategorias.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, CatFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        itemCarrito.setOnClickListener {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, CartFragment())
                .commit()
            drawerLayout.closeDrawers()
        }

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawerLayout)
        val btnMenu = findViewById<Button>(R.id.btt_menu)

        btnMenu.setOnClickListener {
            drawerLayout.openDrawer(findViewById(R.id.ll_menuLateral))
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_inicio -> {
                replaceFragment(StartFragment())
                return true
            }
            R.id.nav_productos -> {
                replaceFragment(ProductsFragment())
                return true
            }
            R.id.nav_perfil -> {
                replaceFragment(ProfileFragment())
                return true
            }
            R.id.nav_categorias -> {
                replaceFragment(CatFragment())
                return true
            }
            R.id.nav_carrito -> {
                replaceFragment(CartFragment())
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, fragment)
            .commit()
    }

}