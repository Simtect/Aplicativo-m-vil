package com.example.taller1m2

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment

class LoginFragment : Fragment() {

    companion object {
        private const val TAG = "LoginFragment"
    }

    private lateinit var et_username: EditText
    private lateinit var et_password: EditText
    private lateinit var btt_login: Button
    private lateinit var tv_register: TextView
    private lateinit var btt_googleLogin: Button
    private lateinit var sharedPreferences: SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Login"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        initializeViews(view)
        sharedPreferences = requireContext().getSharedPreferences("userData", Context.MODE_PRIVATE)

        btt_login.setOnClickListener {
            onLoginClicked()
        }

        tv_register.setOnClickListener {
            redirectToRegister()
        }

        btt_googleLogin.setOnClickListener {
            Toast.makeText(requireContext(), "Esta opción aún no está habilitada", Toast.LENGTH_SHORT).show()
        }

        return view
    }

    private fun initializeViews(view: View) {
        et_username = view.findViewById(R.id.et_username)
        et_password = view.findViewById(R.id.et_password)
        btt_login = view.findViewById(R.id.btt_login)
        tv_register = view.findViewById(R.id.tv_register)
        btt_googleLogin = view.findViewById(R.id.btt_googleLogin)
    }

    private fun onLoginClicked() {
        val email = et_username.text.toString().trim()
        val passwordInput = et_password.text.toString().trim()

        if (email.isEmpty() || passwordInput.isEmpty()) {
            Toast.makeText(requireContext(), "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val storedEmail = sharedPreferences.getString("Email", null)
        val phone = sharedPreferences.getString("Phone", null)
        val password = sharedPreferences.getString("Password", null)
        val firstName = sharedPreferences.getString("FirstName", null)
        val lastName = sharedPreferences.getString("LastName", null)

        Log.d(TAG, "Datos recuperados: Email=$storedEmail, Phone=$phone, Password=$password")

        if (email == storedEmail && passwordInput == password) {
            Toast.makeText(requireContext(), "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
            Log.d(TAG, "Usuario inició sesión correctamente")

            // Guardar sesión
            val sesionPrefs = requireActivity().getSharedPreferences("sesion", Context.MODE_PRIVATE)
            sesionPrefs.edit().putString("usuario", email).apply()

            // Mostrar la opción "Perfil"
            val itemPerfil = requireActivity().findViewById<TextView>(R.id.tv_itemPerfil)
            itemPerfil?.visibility = View.VISIBLE

            // Ocultar la opción "Login"
            val itemLogin = requireActivity().findViewById<TextView>(R.id.tv_itemLogin)
            itemLogin?.visibility = View.GONE

            // Reemplazar fragmento por Inicio
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, StartFragment())
                .commit()
        } else {
            Toast.makeText(requireContext(), "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
        }
    }


    private fun redirectToRegister() {
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, RegisterFragment())
            .addToBackStack(null) // para volver atrás con botón de back
            .commit()
    }

    override fun onDestroy() {
        super.onDestroy()
        sharedPreferences.edit().clear().apply()
        Log.d(TAG, "SharedPreferences borradas automáticamente")
    }
}