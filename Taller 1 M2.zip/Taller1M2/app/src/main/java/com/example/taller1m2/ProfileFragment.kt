package com.example.taller1m2

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    private lateinit var tv_profileName: TextView
    private lateinit var tv_profileEmail: TextView
    private lateinit var tv_profilePhone: TextView
    private lateinit var btt_editProfile: Button
    private lateinit var iv_profilePicture: ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Perfil"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        // Vincular vistas
        tv_profileName = view.findViewById(R.id.tv_profileName)
        tv_profileEmail = view.findViewById(R.id.tv_profileEmail)
        tv_profilePhone = view.findViewById(R.id.tv_profilePhone)
        btt_editProfile = view.findViewById(R.id.btt_editProfile)
        iv_profilePicture = view.findViewById(R.id.iv_profilePicture)

        // Cargar datos
        cargarDatosUsuario()

        // Acción botón editar
        btt_editProfile.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragCont, EditFragment())
                .addToBackStack(null)
                .commit()
        }

        return view
    }

    private fun cargarDatosUsuario() {
        val prefs = requireContext().getSharedPreferences("userData", Context.MODE_PRIVATE)
        val nombre = prefs.getString("FirstName", "") ?: ""
        val apellido = prefs.getString("LastName", "") ?: ""
        val email = prefs.getString("Email", "") ?: ""
        val telefono = prefs.getString("Phone", "") ?: ""

        tv_profileName.text = "$nombre $apellido"
        tv_profileEmail.text = email
        tv_profilePhone.text = telefono

        // Mostrar inicial si no hay imagen personalizada
        if (nombre.isNotEmpty()) {
            val inicial = nombre.first().uppercaseChar().toString()
            iv_profilePicture.visibility = View.GONE
        } else {
            iv_profilePicture.visibility = View.VISIBLE
        }
    }
}