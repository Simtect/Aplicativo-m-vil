package com.example.taller1m2

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import org.json.JSONArray
import org.json.JSONObject

class CartFragment : Fragment() {

    private lateinit var lv_listaCarrito: ListView
    private lateinit var tv_totalProductos: TextView
    private lateinit var tv_precioTotal: TextView
    private lateinit var btt_pagar: Button
    private lateinit var prefs: android.content.SharedPreferences

    private var productos = mutableListOf<JSONObject>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Carrito"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        lv_listaCarrito = view.findViewById(R.id.lv_listaCarrito)
        tv_totalProductos = view.findViewById(R.id.tv_totalProductos)
        tv_precioTotal = view.findViewById(R.id.tv_precioTotal)
        btt_pagar = view.findViewById(R.id.btt_pagar)
        prefs = requireContext().getSharedPreferences("carrito", Context.MODE_PRIVATE)

        cargarProductos()
        configurarBotonPagar()

        return view
    }

    private fun cargarProductos() {
        productos.clear()
        val carritoString = prefs.getString("productos", "[]") ?: "[]"
        val jsonArray = JSONArray(carritoString)

        for (i in 0 until jsonArray.length()) {
            productos.add(jsonArray.getJSONObject(i))
        }

        lv_listaCarrito.adapter = object : BaseAdapter() {
            override fun getCount(): Int = productos.size
            override fun getItem(position: Int): Any = productos[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val view = layoutInflater.inflate(R.layout.item_cart, parent, false)
                val producto = productos[position]

                val nombre = view.findViewById<TextView>(R.id.tv_carritoNombre)
                val precio = view.findViewById<TextView>(R.id.tv_carritoPrecio)
                val cantidad = view.findViewById<TextView>(R.id.tv_carritoCantidad)
                val subtotal = view.findViewById<TextView>(R.id.tv_carritoSubtotal)
                val btnEliminar = view.findViewById<Button>(R.id.btt_eliminar)

                val nombreText = producto.getString("nombre")
                val precioText = producto.getString("precio").replace(Regex("[^\\d.]"), "")
                val cantidadSeleccionada = producto.optInt("cantidadSeleccionada", 1)

                val precioVal = precioText.toDoubleOrNull() ?: 0.0
                val subtotalVal = precioVal * cantidadSeleccionada

                nombre.text = "Nombre: $nombreText"
                precio.text = "Precio: $${"%.2f".format(precioVal)}"
                cantidad.text = "Cantidad: $cantidadSeleccionada"
                subtotal.text = "Subtotal: $${"%.2f".format(subtotalVal)}"

                btnEliminar.setOnClickListener {
                    productos.removeAt(position)
                    guardarProductos()
                    cargarProductos()
                    Toast.makeText(requireContext(), "$nombreText eliminado del carrito", Toast.LENGTH_SHORT).show()
                }

                return view
            }
        }

        actualizarResumen()
    }

    private fun actualizarResumen() {
        var totalProductos = 0
        var precioTotal = 0.0

        for (producto in productos) {
            val precioText = producto.getString("precio").replace(Regex("[^\\d.]"), "")
            val precioVal = precioText.toDoubleOrNull() ?: 0.0
            val cantidadSeleccionada = producto.optInt("cantidadSeleccionada", 1)

            totalProductos += cantidadSeleccionada
            precioTotal += precioVal * cantidadSeleccionada
        }

        tv_totalProductos.text = "Total productos: $totalProductos"
        tv_precioTotal.text = "Precio total: $${"%.2f".format(precioTotal)}"
    }

    private fun guardarProductos() {
        val array = JSONArray()
        for (producto in productos) {
            array.put(producto)
        }
        prefs.edit().putString("productos", array.toString()).apply()
    }

    private fun configurarBotonPagar() {
        btt_pagar.setOnClickListener {
            if (productos.isEmpty()) {
                Toast.makeText(requireContext(), "El carrito está vacío", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Gracias por tu compra 🛒", Toast.LENGTH_SHORT).show()
                productos.clear()
                guardarProductos()
                cargarProductos()
            }
        }
    }
}