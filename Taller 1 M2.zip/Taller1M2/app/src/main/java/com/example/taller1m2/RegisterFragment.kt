package com.example.taller1m2

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment

class RegisterFragment : Fragment() {

    companion object {
        private const val TAG = "RegisterFragment"
    }

    private lateinit var et_firstName: EditText
    private lateinit var et_lastName: EditText
    private lateinit var et_email: EditText
    private lateinit var et_phone: EditText
    private lateinit var et_password: EditText
    private lateinit var et_repeatPassword: EditText
    private lateinit var cb_terms: CheckBox
    private lateinit var btt_register: Button
    private lateinit var tv_loginRedirect: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Registro"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_register, container, false)

        et_firstName = view.findViewById(R.id.et_firstName)
        et_lastName = view.findViewById(R.id.et_lastName)
        et_email = view.findViewById(R.id.et_email)
        et_phone = view.findViewById(R.id.et_phone)
        et_password = view.findViewById(R.id.et_password)
        et_repeatPassword = view.findViewById(R.id.et_repeatPassword)
        cb_terms = view.findViewById(R.id.cb_terms)
        btt_register = view.findViewById(R.id.btt_register)
        tv_loginRedirect = view.findViewById(R.id.tv_loginRedirect)

        btt_register.setOnClickListener {
            onRegisterClicked()
        }

        tv_loginRedirect.setOnClickListener {
            redirectToLogin()
        }

        return view
    }

    private fun onRegisterClicked() {
        val firstName = et_firstName.text.toString().trim()
        val lastName = et_lastName.text.toString().trim()
        val email = et_email.text.toString().trim()
        val phone = et_phone.text.toString().trim()
        val password = et_password.text.toString().trim()
        val repeatPassword = et_repeatPassword.text.toString().trim()

        if (validateInputs(firstName, lastName, email, phone, password, repeatPassword)) {
            Toast.makeText(requireContext(), "Registro exitoso", Toast.LENGTH_SHORT).show()
            saveUserData(firstName, lastName, email, phone, password)
            redirectToLogin()
        }
    }

    private fun saveUserData(firstName: String, lastName: String, email: String, phone: String, password: String) {
        val prefs: SharedPreferences = requireContext().getSharedPreferences("userData", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putString("FirstName", firstName)
            putString("LastName", lastName)
            putString("Email", email)
            putString("Phone", phone)
            putString("Password", password)
            apply()
        }
        Log.d(TAG, "Datos guardados en SharedPreferences")
    }

    private fun validateInputs(firstName: String, lastName: String, email: String, phone: String, password: String, repeatPassword: String): Boolean {
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty() || repeatPassword.isEmpty()) {
            Toast.makeText(requireContext(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            return false
        }
        if (!email.contains("@")) {
            Toast.makeText(requireContext(), "Correo electrónico inválido", Toast.LENGTH_SHORT).show()
            return false
        }
        if (password != repeatPassword) {
            Toast.makeText(requireContext(), "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            return false
        }
        if (!cb_terms.isChecked) {
            Toast.makeText(requireContext(), "Debes aceptar los términos y condiciones", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun redirectToLogin() {
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, LoginFragment())
            .addToBackStack(null)
            .commit()
    }
}