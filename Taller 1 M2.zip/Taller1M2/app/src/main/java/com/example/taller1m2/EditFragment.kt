package com.example.taller1m2

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment

class EditFragment : Fragment() {

    private lateinit var et_nombre: EditText
    private lateinit var et_apellido: EditText
    private lateinit var et_correo: EditText
    private lateinit var et_telefono: EditText
    private lateinit var btt_guardarEdit: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Editar Perfil"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_edit, container, false)

        et_nombre = view.findViewById(R.id.et_nombre)
        et_apellido = view.findViewById(R.id.et_apellido)
        et_correo = view.findViewById(R.id.et_correo)
        et_telefono = view.findViewById(R.id.et_telefono)
        btt_guardarEdit = view.findViewById(R.id.btt_guardarEdit)

        cargarDatos()

        btt_guardarEdit.setOnClickListener {
            guardarDatos()
        }

        return view
    }

    private fun cargarDatos() {
        val prefs = requireContext().getSharedPreferences("userData", Context.MODE_PRIVATE)
        et_nombre.setText(prefs.getString("FirstName", ""))
        et_apellido.setText(prefs.getString("LastName", ""))
        et_correo.setText(prefs.getString("Email", ""))
        et_telefono.setText(prefs.getString("Phone", ""))
    }

    private fun guardarDatos() {
        val prefs = requireContext().getSharedPreferences("userData", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putString("FirstName", et_nombre.text.toString())
            putString("LastName", et_apellido.text.toString())
            putString("Email", et_correo.text.toString())
            putString("Phone", et_telefono.text.toString())
            apply()
        }

        Toast.makeText(requireContext(), "Datos actualizados correctamente", Toast.LENGTH_SHORT).show()

        // Volver al fragmento de perfil
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, ProfileFragment())
            .commit()
    }
}