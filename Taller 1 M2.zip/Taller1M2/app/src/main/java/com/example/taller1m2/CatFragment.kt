package com.example.taller1m2

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment

class CatFragment : Fragment() {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Categorias"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_cat, container, false)

        view.findViewById<LinearLayout>(R.id.ll_cardClothes).setOnClickListener {
            abrirFragment(ClothesFragment())
        }

        view.findViewById<LinearLayout>(R.id.ll_cardHogar).setOnClickListener {
            abrirFragment(HomeCatFragment())
        }

        view.findViewById<LinearLayout>(R.id.ll_cardAccesories).setOnClickListener {
            abrirFragment(AccesoriesFragment())
        }

        view.findViewById<LinearLayout>(R.id.cardDeportes).setOnClickListener {
            abrirFragment(SportsFragment())
        }

        view.findViewById<LinearLayout>(R.id.cardElectronica).setOnClickListener {
            abrirFragment(ElectronicFragment())
        }
        return view
    }

    private fun abrirFragment(fragment: Fragment) {
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fragCont, fragment)
            .addToBackStack(null)
            .commit()
    }
}