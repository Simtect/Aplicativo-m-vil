package com.example.taller1m2

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import org.json.JSONArray
import org.json.JSONObject

class ProductsFragment : Fragment() {

    private lateinit var listView: ListView
    private lateinit var prefs: SharedPreferences

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cambiar el texto del TextView que está en la Activity
        val titulo = activity?.findViewById<TextView>(R.id.tv_tituloFrag)
        titulo?.text = "Productos"
    }

    override fun onCreateView(

        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_products, container, false)

        listView = view.findViewById(R.id.lv_listaProductos)
        prefs = requireContext().getSharedPreferences("carrito", Context.MODE_PRIVATE)

        val productos = listOf(
            mapOf("nombre" to "Pelota para perros", "descripcion" to "PAra jugar con tu mascota", "precio" to "Precio: $29.900", "cantidad" to "Disponible: 10"),
            mapOf("nombre" to "Audifonos", "descripcion" to "Ergonomicos con gran sonido", "precio" to "Precio: $99.900", "cantidad" to "Disponible: 7"),
            mapOf("nombre" to "Guantes", "descripcion" to "Para momentos de frio", "precio" to "Precio: $34.500", "cantidad" to "Disponible: 12")
        )

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = productos.size
            override fun getItem(position: Int): Any = productos[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val inflater = LayoutInflater.from(requireContext())
                val viewItem = convertView ?: inflater.inflate(R.layout.item_product, parent, false)

                val producto = productos[position]

                viewItem.findViewById<TextView>(R.id.tv_lineaNombre).text = producto["nombre"]
                viewItem.findViewById<TextView>(R.id.tv_lineaDescripcion).text = producto["descripcion"]
                viewItem.findViewById<TextView>(R.id.tv_lineaPrecio).text = producto["precio"]
                viewItem.findViewById<TextView>(R.id.tv_lineaCantidad).text = producto["cantidad"]

                viewItem.findViewById<Button>(R.id.btt_agregar).setOnClickListener {
                    agregarAlCarrito(producto)
                    Toast.makeText(requireContext(), "${producto["nombre"]} añadido al carrito", Toast.LENGTH_SHORT).show()
                }

                return viewItem
            }
        }

        listView.adapter = adapter
        return view
    }

    private fun agregarAlCarrito(producto: Map<String, String>) {
        val carritoActual = prefs.getString("productos", "[]")
        val jsonArray = JSONArray(carritoActual)

        val nombreNuevo = producto["nombre"]
        var productoExiste = false

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            if (item.getString("nombre") == nombreNuevo) {
                // Ya existe: aumentar la cantidadSeleccionada
                val cantidadActual = item.optInt("cantidadSeleccionada", 1)
                item.put("cantidadSeleccionada", cantidadActual + 1)
                productoExiste = true
                break
            }
        }

        if (!productoExiste) {
            // No existe: crear nuevo objeto con cantidadSeleccionada = 1
            val nuevoProducto = JSONObject()
            for ((key, value) in producto) {
                nuevoProducto.put(key, value)
            }
            nuevoProducto.put("cantidadSeleccionada", 1)
            jsonArray.put(nuevoProducto)
        }

        prefs.edit().putString("productos", jsonArray.toString()).apply()
    }
}